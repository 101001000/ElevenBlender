import json

class Message(dict):

    # Message:
    # data:
    # data_size (in bytes)
    # data_format: float4, json, string
    # type: data, command, status

    MESSAGE_HEADER_SIZE = 1024

    def __init__(self):
        self.__dict__ = dict()

    def TextureMetadataMessage(image):
        
        msg = Message()
        
        tex_metadata = dict()
        tex_metadata["name"] = image.name
        tex_metadata["width"] = int(image.size[0])
        tex_metadata["height"] = int(image.size[1]) 
        tex_metadata["color_space"] = image.colorspace_settings.name
        
        byte_data = bytearray(json.dumps(tex_metadata, indent = 4).encode()) + b'\00'
        
        msg.__dict__["type"] = "data"
        msg.__dict__["data"] = dict()
        msg.__dict__["data"]["data_type"] = "json"
        msg.__dict__["data"]["data"] = tex_metadata
        msg.__dict__["data"]["data_size"] = len(byte_data)
        
        return msg

    def TextureDataMessage(image):
        
        msg = Message()
        
        arr = np.empty((image.size[1] * image.size[0] * 4), dtype=np.single)
        image.pixels.foreach_get(arr)
        
        msg.__dict__["type"] = "data"
        msg.__dict__["data_format"] = "float4"
        msg.__dict__["data_size"] = len(arr)*4
        msg.__dict__["data"] = arr
        
        return msg
            
    def SendTextureCommandMessage(mode="tcp"):
            
        msg = Message()
        
        if mode == "tcp":
            msg.__dict__["type"] = "command"
            msg.__dict__["data_format"] = "string"
            msg.__dict__["data"] = "--load_texture --mode='tcp'"
            msg.__dict__["data_size"] = len(msg.__dict__["data"]) + 1
        
        
        return msg
        

    def ConfigDataMessage(config):
            
        msg = Message()
        byte_data = bytearray(json.dumps(config, indent = 4).encode()) + b'\00'
            
        msg.__dict__["type"] = "data"
        msg.__dict__["data_format"] = "json"
        msg.__dict__["data"] = config
        msg.__dict__["data_size"] = len(msg.__dict__["data"])
        
        return msg

    def SendConfigMessage(mode="tcp"):
            
        msg = Message()
        
        if mode == "tcp":
            msg.__dict__["type"] = "command"
            msg.__dict__["data_format"] = "string"
            msg.__dict__["data"] = "--load_config --mode='tcp'"
            msg.__dict__["data_size"] = len(msg.__dict__["data"]) + 1
        
        
        return msg


    def SendHDRIMessage(mode="tcp"):
            
        msg = Message()
        
        if mode == "tcp":
            msg.__dict__["type"] = "command"
            msg.__dict__["data_format"] = "string"
            msg.__dict__["data"] = "--load_hdri --mode='tcp'"
            msg.__dict__["data_size"] = len(msg.__dict__["data"]) + 1
        
        
        return msg



    #TODO: Abstracting Send messages

