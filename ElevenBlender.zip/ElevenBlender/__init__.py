import bpy


from .panel import ElevenPanel
from .engine import ElevenEngine



bl_info = {
    "name": "Eleven Render",
    "description": "A super-compatible GPU/CPU rendering engine",
    "author": "Enrique de la Calle",
    "version": (0, 1),
    "blender": (3, 2, 0),
    "location": "Scene > Render > Eleven",
    "warning": "Extremely unstable",
    "doc_url": "https://github.com/101001000/ElevenBlender",
    "tracker_url": "https://github.com/101001000/ElevenBlender/issues",
    "support": "COMMUNITY",
    "category": "Render"
}



def get_panels():
    exclude_panels = {
        'VIEWLAYER_PT_filter',
        'VIEWLAYER_PT_layer_passes',
    }

    panels = []
    for panel in bpy.types.Panel.__subclasses__():
        if hasattr(panel, 'COMPAT_ENGINES') and 'BLENDER_RENDER' in panel.COMPAT_ENGINES:
            if panel.__name__ not in exclude_panels:
                panels.append(panel)

    return panels


def register():
    bpy.utils.register_class(ElevenEngine)

    for panel in get_panels():
        panel.COMPAT_ENGINES.add('ELEVEN')
        
    bpy.utils.register_class(ElevenPanel)


def unregister():
    bpy.utils.unregister_class(ElevenEngine)

    for panel in get_panels():
        if 'ELEVEN' in panel.COMPAT_ENGINES:
            panel.COMPAT_ENGINES.remove('ELEVEN')
            
    bpy.utils.unregister_class(ElevenPanel)


if __name__ == "__main__":
    register()